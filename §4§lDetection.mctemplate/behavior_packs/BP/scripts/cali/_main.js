import { system,world } from "@minecraft/server";  
export const ver = "0.4.0";  
export const initTime = 105;  
export const ram = "@e [type=loadisk:ram]"; 
export const v = world.getDimension("overworld"); 
let curTick = 0; 
function init() { 
    try { 
        v.runCommandAsync('function cali/init'); 
        v.runCommandAsync(`execute as ${ram} run function cali/v.localize`); 
    } catch (e) { } 
} 
function tick() { 
    try {if (curTick === initTime) {init();}curTick++;}  
    catch (e) {console.warn("Tick error: " + e);} 
    v.runCommandAsync("function cali/_main"); 
    system.run(tick); 
} 
system.run(tick); 
