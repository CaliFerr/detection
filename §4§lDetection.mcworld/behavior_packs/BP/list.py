X =1
Y =96
for i in range(100):
  print("execute @e[type=loadisk:ram,scores={t.end=",X,"}] ~ ~ ~ summon loadisk:obj 1035 76 1025 loadisk:add.name_always_event \"§5Loading:§r",X,"%\"")
  print("execute @e[type=loadisk:ram,scores={t.end=",X,"}] ~ ~ ~ event entity @e[name=\"§6Days Alive:§r",X,"\" loadisk:despawn_event")
  X = X + 1 
  Y = Y - 5  